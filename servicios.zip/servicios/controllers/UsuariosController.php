<?php namespace controllers;

class UsuariosController{
    var $container;
    // Es necesario iniciar con una inyeccion de dependencia
    function __construct($container){
        $this->container = $container;
    }

    // Funcion que realiza la logica de negocio, en este caso
    // solo va a recibir los datos del model, sin procesarlos
    function Usuario($data){
        $model = $this->container->get('usuariosModel');
        $response = '';

        try{
            $response = $model->Usuario($data);
        }catch(\Exception $ex){
            throw new \Exception($ex->getMessage());
        }
        
        return $response;
    }
}
