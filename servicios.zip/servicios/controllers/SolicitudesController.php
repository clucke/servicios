<?php namespace controllers;

class SolicitudesController{
    var $container;
    // Es necesario iniciar con una inyeccion de dependencia
    function __construct($container){
        $this->container = $container;
    }

    // Funcion que realiza la logica de negocio, en este caso
    // solo va a recibir los datos del model, sin procesarlos
    function Solicitud($data){
        $model = $this->container->get('solicitudesModel');
        $response = '';
        
        try{
            $response = $model->Solicitud($data);
        }catch(\Exception $ex){
            throw new \Exception($ex->getMessage());
        }
        
        return $response;
    }
}
