<?php
class Pruebas extends PHPUnit_Framework_TestCase
{
    protected $client;

    protected function setUp()
    {
        $this->client = new GuzzleHttp\Client([
            'base_uri' => 'http://localhost/'
        ]);
    }

    public function testPost_servicio_usuarios()
    {
        $response = $this->client->post('/servicios/public/', [
            GuzzleHttp\RequestOptions::JSON =>[
                'opcion'=>4,
                'servicio'=>'usuarios'
        ]]);
        
        $this->assertEquals(200, $response->getStatusCode());
        $data = json_decode($response->getBody(),true);
        $this->assertEquals(1, $data['status']);
    }

    public function testPost_servicio_solicitudes()
    {
        $response = $this->client->post('/servicios/public/', [
            GuzzleHttp\RequestOptions::JSON =>[
                'opcion'=>6,
                'servicio'=>'solicitudes'
        ]]);
        
        $this->assertEquals(200, $response->getStatusCode());
        $data = json_decode($response->getBody(),true);
        $this->assertEquals(1, $data['status']);
    }
}