<?php

$container = $app->getContainer();

//Config
$container['config'] = function ($container) {
    $config = require '../config/config.php';
    return $config;
};

//Controladores
$container['usuariosController'] = function ($container) {
    return new controllers\UsuariosController($container);
};
$container['solicitudesController'] = function ($container) {
    return new controllers\SolicitudesController($container);
};

//Modelos
$container['usuariosModel'] = function ($container) {
    return new models\UsuariosModel($container);
};
$container['solicitudesModel'] = function ($container) {
    return new models\SolicitudesModel($container);
};

//Conexiones
$container['db'] = function ($container) {
    $config = $container->get('config')['db'];
    $pdo = new PDO("mysql:host=" . $config['host'] . ";dbname=" . $config['dbname'],
        $config['user'], $config['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
};