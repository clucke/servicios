<?php namespace models;

class SolicitudesModel{
    var $container;
    // Es necesario iniciar con una inyeccion de dependencia
    function __construct($container){
        $this->container = $container;
    }

    // Funcion que ejecutar un procedimiento en la base de datos
    // y regresa una consulta
    function Solicitud($data){
        $response = '';
        $arr = array(
            $data['opcion'],
            $data['usuario'],
            $data['edad'],
            $data['tarjeta'],
            $data['plazo'],
            $data['interes'],
            $data['solicitado'],
            $data['total']
        );
        $pdo = $this->container->get('db');
        $stmt = $pdo->prepare("call proc_solicitudes(?,?,?,?,?,?,?,?)");
        $stmt->execute($arr);
        $response = $stmt->fetchAll();

        return $response;
    }
}