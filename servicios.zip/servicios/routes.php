<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    $app->post('/', function (Request $request, Response $response, array $args) {
        $response = '';
        $data = new stdClass();
        $data = $request->getParsedBody();
        // Se valida si en el json se envia la propiedad servicio
        if(isset($data['servicio'])){
            $servicio = $data['servicio'];
            try{
                // Se valida que servicio se va a utilizar
                if($servicio=='usuarios'){
                    $controller = $this->get('usuariosController');
                    $response = $controller->Usuario($data);
                    $response = ['data'=>$response, 'status' => 1];
                }else if($servicio=='solicitudes'){
                    $controller = $this->get('solicitudesController');
                    $response = $controller->Solicitud($data);
                    $response = ['data'=>$response, 'status' => 1];
                }else{
                    $response = ['message' => 'Servicio no encontrado', 'status' => 0];
                }
            }catch(\Exception $ex){
                $response = ['message' => $ex->getMessage(),'status' => -1];
            }
        }else{
            $response = ['message' => 'Servicio no encontrado', 'status' => 0];
        }

        $response = JSON_encode($response);
        return $response;
    });
