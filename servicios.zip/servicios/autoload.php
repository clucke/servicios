<?php
    spl_autoload_register(function($archivo){
        $ruta = str_replace("\\","/",$archivo) . ".php";
        $ruta = '../'.$ruta;
        if(is_readable($ruta)){
            require_once $ruta;
        }
    })
?>