<?php
return [
    "db" => [
        "host" => "localhost",
        "dbname" => "clientes",
        "user" => "root",
        "pass" => "pass"
    ]
];