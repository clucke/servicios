<?php
    require '../autoload.php';
    require '../vendor/autoload.php';

    $container = new \Slim\Container;
    $app = new \Slim\App($container);
    // Se cargan las dependencias necesarias
    // como controladores, modelos y conexion a base de datos
    require '../container.php';
    // Se agregan las rutas, logica de entrada de datos
    // y se llama a su respectivo controlador
    require '../routes.php';
    $app->run();